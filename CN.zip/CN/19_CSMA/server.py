import socket
import time

HOST = "127.0.0.1"
PORT = 6219

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_socket.bind((HOST, PORT))
server_socket.listen()
print(f"CSMA Channel Server running on {HOST}:{PORT}")

channel_busy_until = 0

while True:
    client_socket, client_address = server_socket.accept()
    request = client_socket.recv(1024).decode().strip()
    current_time = time.time()

    if request == "SENSE":
        if current_time < channel_busy_until:
            reply = "BUSY"
        else:
            reply = "IDLE"
        print(f"Node sensed carrier: Channel is {reply}")
    elif request.startswith("TRANSMIT:"):
        payload = request.split(":", 1)[1]
        channel_busy_until = current_time + 2.0
        reply = f"ACK: Transmitted '{payload}'. Channel reserved for 2s."
        print(f"Received transmission: '{payload}' -> Channel set to BUSY for 2s")
    else:
        reply = "ERROR: Unknown command"

    client_socket.sendall(reply.encode())
    client_socket.close()
