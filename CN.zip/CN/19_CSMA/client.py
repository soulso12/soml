import socket
import time

SERVER_HOST = "127.0.0.1"
SERVER_PORT = 6219

data_to_send = input("Enter data to transmit over CSMA channel: ").strip() or "SensorData-123"

while True:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((SERVER_HOST, SERVER_PORT))
    s.sendall(b"SENSE")
    status = s.recv(1024).decode().strip()
    s.close()

    print(f"Carrier Sense Result: {status}")

    if status == "IDLE":
        print("Channel is IDLE! Transmitting data now...")
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((SERVER_HOST, SERVER_PORT))
        s.sendall(f"TRANSMIT:{data_to_send}".encode())
        ack = s.recv(1024).decode().strip()
        print("Server Response:", ack)
        s.close()
        break
    else:
        print("Channel is BUSY! Backing off for 1 second...")
        time.sleep(1.0)
