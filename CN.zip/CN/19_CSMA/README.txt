=============================================================================
TOPIC 19: CARRIER SENSE MULTIPLE ACCESS (CSMA)
=============================================================================
Media access protocol where nodes sense the channel before transmitting.
If IDLE -> Transmit.
If BUSY -> Back off and retry. (Port: 6219)

HOW TO RUN:
1. Socket Demo (2 terminals):
   Terminal 1: python server.py
   Terminal 2: python client.py

2. SimPy Simulation:
   Terminal: python simpy_simulation.py
=============================================================================
