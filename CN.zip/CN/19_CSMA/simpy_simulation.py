import simpy
import random

random.seed(9)

NODES = 4

def node(env, name, channel):
    for pkt in range(1, 3):
        yield env.timeout(random.uniform(0.5, 2.0))
        print(f"[Time {env.now:.2f}s] {name} wants to send packet {pkt}. Sensing carrier...")

        while True:
            if channel.count == 0:
                with channel.request() as req:
                    yield req
                    print(f"[Time {env.now:.2f}s] {name} channel is IDLE! Transmitting...")
                    yield env.timeout(1.0)
                    print(f"[Time {env.now:.2f}s] {name} finished transmission.")
                break
            else:
                backoff = random.uniform(0.3, 0.8)
                print(f"[Time {env.now:.2f}s] {name} channel is BUSY! Backoff for {backoff:.2f}s")
                yield env.timeout(backoff)

env = simpy.Environment()
shared_channel = simpy.Resource(env, capacity=1)

for i in range(1, NODES + 1):
    env.process(node(env, f"Node-{i}", shared_channel))

env.run()
