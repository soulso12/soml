import socket

HOST = "127.0.0.1"
PORT = 6207

udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
udp_socket.bind((HOST, PORT))
print(f"UDP Server listening on {HOST}:{PORT}")

while True:
    data, sender_address = udp_socket.recvfrom(2048)
    msg = data.decode().strip()
    print("Received from", sender_address, ":", msg)

    reply = f"ACK: {msg}"
    udp_socket.sendto(reply.encode(), sender_address)
