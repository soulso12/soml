=============================================================================
TOPIC 07: UDP PROTOCOL AND PACKET LOSS
=============================================================================

WHAT IS THIS TOPIC?
    UDP (User Datagram Protocol) is a connectionless transport protocol. It does
    not perform handshakes or guarantee delivery, making it fast but subject to
    packet loss and out-of-order arrival.

FILES IN THIS FOLDER:
    1. server.py            - UDP Server on port 6207: Uses recvfrom() and sendto().
    2. client.py            - UDP Client: Sends datagrams with timeout handling.
    3. simpy_simulation.py  - Simulates 20 packets across an unreliable lossy channel.

HOW TO RUN:
    Method 1: Socket Demo (requires 2 terminals)
        Terminal 1: python server.py
        Terminal 2: python client.py
        (Enter any message)

    Method 2: SimPy Simulation (single terminal)
        Terminal:   python simpy_simulation.py
=============================================================================
