import simpy
import random

random.seed(12)

TOTAL_PACKETS = 20
LOSS_RATE = 0.20

def packet(env, pkt_id, stats):
    departure = env.now
    delay = random.uniform(0.2, 1.2)
    yield env.timeout(delay)

    if random.random() < LOSS_RATE:
        stats["lost"] += 1
        print(f"[Time {env.now:.2f}s] Packet {pkt_id} -> Lost")
    else:
        stats["received"] += 1
        stats["delays"].append(delay)
        print(f"[Time {env.now:.2f}s] Packet {pkt_id} -> Delivered (Delay: {delay:.2f}s)")

env = simpy.Environment()
stats = {"received": 0, "lost": 0, "delays": []}

for i in range(1, TOTAL_PACKETS + 1):
    env.process(packet(env, i, stats))

env.run()

print("Delivered:", stats["received"])
print("Lost:", stats["lost"])
print("Delivery Ratio (%):", (stats["received"] / TOTAL_PACKETS) * 100)
