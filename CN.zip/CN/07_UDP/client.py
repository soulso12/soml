import socket

SERVER_HOST = "127.0.0.1"
SERVER_PORT = 6207

msg = input("Enter UDP message: ").strip() or "Hello via UDP"

client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
client_socket.settimeout(3.0)

try:
    client_socket.sendto(msg.encode(), (SERVER_HOST, SERVER_PORT))
    data, server = client_socket.recvfrom(2048)
    print("Server Response:", data.decode())
except socket.timeout:
    print("Timeout: No response received (packet may be lost).")
finally:
    client_socket.close()
