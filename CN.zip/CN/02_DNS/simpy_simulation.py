import simpy

DNS_DATABASE = {
    "www.example.com": "192.0.2.10",
    "www.example.org": "192.0.2.20"
}

DOMAINS = [
    "www.example.com",
    "www.example.org",
    "unknown.com"
]

def lookup(env, domain, resource):
    arrival = env.now
    with resource.request() as req:
        yield req
        yield env.timeout(0.5)
        print(f"Root DNS checked for {domain} at {env.now}s")
        yield env.timeout(0.5)
        print(f"TLD DNS checked for {domain} at {env.now}s")
        yield env.timeout(0.8)
        print(f"Authoritative DNS checked for {domain} at {env.now}s")

        ip = DNS_DATABASE.get(domain, "Not Found")
        print(f"Resolved {domain} -> {ip} (Latency: {env.now - arrival}s)")

env = simpy.Environment()
dns_resource = simpy.Resource(env, capacity=1)

for d in DOMAINS:
    env.process(lookup(env, d, dns_resource))

env.run()
