import socket

HOST = "127.0.0.1"
PORT = 6202

DNS_DATABASE = {
    "www.example.com": "192.0.2.10",
    "www.example.org": "192.0.2.20",
    "www.google.com": "142.250.190.46",
    "www.github.com": "140.82.121.4"
}

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_socket.bind((HOST, PORT))
server_socket.listen()
print(f"DNS Server running on {HOST}:{PORT}")

while True:
    client_socket, client_address = server_socket.accept()
    domain = client_socket.recv(1024).decode().strip().lower()
    print("Received query for:", domain)

    if domain in DNS_DATABASE:
        reply = f"IP: {DNS_DATABASE[domain]}"
    else:
        reply = "Domain not found in DNS database"

    client_socket.sendall(reply.encode())
    client_socket.close()
