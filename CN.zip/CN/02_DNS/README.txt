=============================================================================
TOPIC 02: DOMAIN NAME SYSTEM (DNS)
=============================================================================

WHAT IS THIS TOPIC?
    DNS translates human-readable hostnames (e.g. www.google.com) to machine
    IP addresses (e.g. 142.250.190.46).

FILES IN THIS FOLDER:
    1. server.py            - Listens on port 6202 and resolves Domain -> IP.
    2. client.py            - Connects to server, inputs domain, displays IP.
    3. simpy_simulation.py  - Simulates hierarchical DNS resolution delays.

HOW TO RUN:
    Method 1: Socket Demo (requires 2 terminals)
        Terminal 1: python server.py
        Terminal 2: python client.py
        (Enter: www.example.com)

    Method 2: SimPy Simulation (single terminal)
        Terminal:   python simpy_simulation.py
=============================================================================
