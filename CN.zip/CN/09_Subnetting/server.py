import socket
import ipaddress

HOST = "127.0.0.1"
PORT = 6209

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_socket.bind((HOST, PORT))
server_socket.listen()
print(f"Subnet Server running on {HOST}:{PORT}")

while True:
    client_socket, client_address = server_socket.accept()
    raw_input = client_socket.recv(1024).decode().strip()
    print("Received CIDR:", raw_input)

    try:
        interface = ipaddress.ip_interface(raw_input)
        net = interface.network
        first = str(net.network_address + 1) if net.num_addresses > 2 else "N/A"
        last = str(net.broadcast_address - 1) if net.num_addresses > 2 else "N/A"
        reply = (
            f"Network: {net.network_address}\n"
            f"Broadcast: {net.broadcast_address}\n"
            f"Netmask: {net.netmask}\n"
            f"Total Hosts: {net.num_addresses}\n"
            f"First Host: {first}\n"
            f"Last Host: {last}"
        )
    except Exception:
        reply = "Error: Invalid IPv4 CIDR string"

    client_socket.sendall(reply.encode())
    client_socket.close()
