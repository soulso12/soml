import simpy
import ipaddress

REQUESTS = [
    "192.168.1.25/24",
    "10.0.0.8/8",
    "172.16.0.0/16",
    "bad-cidr"
]

def job(env, job_id, cidr_str, server):
    arrival = env.now
    with server.request() as req:
        yield req
        yield env.timeout(1.0)
        try:
            net = ipaddress.ip_interface(cidr_str).network
            result = f"Network={net.network_address}, Broadcast={net.broadcast_address}, Hosts={net.num_addresses}"
        except ValueError:
            result = "Invalid CIDR"
        print(f"[Time {env.now}s] Job {job_id} ({cidr_str}) -> {result} | Turnaround: {env.now - arrival}s")

env = simpy.Environment()
server = simpy.Resource(env, capacity=1)

for i, c in enumerate(REQUESTS, 1):
    env.process(job(env, i, c, server))

env.run()
