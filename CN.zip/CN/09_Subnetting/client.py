import socket

SERVER_HOST = "127.0.0.1"
SERVER_PORT = 6209

cidr = input("Enter IPv4 with CIDR (e.g. 192.168.1.25/24): ").strip() or "192.168.1.25/24"

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.settimeout(5.0)

try:
    client_socket.connect((SERVER_HOST, SERVER_PORT))
    client_socket.sendall(cidr.encode())
    reply = client_socket.recv(2048).decode()
    print("Server Response:\n" + reply)
except Exception as e:
    print("Error:", e)
finally:
    client_socket.close()
