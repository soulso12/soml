=============================================================================
TOPIC 09: IP SUBNETTING & CIDR
=============================================================================

WHAT IS THIS TOPIC?
    Subnetting splits large IP networks into smaller subnets. Given a CIDR
    notation (e.g. 192.168.1.25/24), we calculate network address, broadcast
    address, subnet mask, and usable host address range.

FILES IN THIS FOLDER:
    1. server.py            - Calculator Server on port 6209: Computes full subnet breakdown.
    2. client.py            - Client: Inputs CIDR string and displays formatted analysis.
    3. simpy_simulation.py  - Simulates an IPAM calculation queue.

HOW TO RUN:
    Method 1: Socket Demo (requires 2 terminals)
        Terminal 1: python server.py
        Terminal 2: python client.py
        (Enter: 192.168.1.25/24)

    Method 2: SimPy Simulation (single terminal)
        Terminal:   python simpy_simulation.py
=============================================================================
