import socket
import time

SERVER_HOST = "127.0.0.1"
SERVER_PORT = 6218
TOTAL_FRAMES = 6

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect((SERVER_HOST, SERVER_PORT))
print(f"Connected to Selective Repeat Receiver. Total frames: {TOTAL_FRAMES}")

unacked = list(range(TOTAL_FRAMES))

while unacked:
    frame_to_send = unacked[0]
    print(f"Sending Frame {frame_to_send}")
    client_socket.sendall(str(frame_to_send).encode())

    ack = client_socket.recv(1024).decode().strip()
    print("Received:", ack)

    ack_seq = int(ack.split()[1])
    if ack_seq in unacked:
        unacked.remove(ack_seq)
        print(f"Frame {ack_seq} acknowledged. Remaining unacked: {unacked}")

    time.sleep(0.5)

client_socket.sendall(b"done")
client_socket.close()
print("All frames acknowledged selectively.")
