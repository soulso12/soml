import simpy
import random

random.seed(8)

TOTAL_FRAMES = 6
LOSS_PROBABILITY = 0.30

def selective_repeat_sender(env):
    unacknowledged = list(range(TOTAL_FRAMES))

    while unacknowledged:
        current_frame = unacknowledged[0]
        print(f"[Time {env.now:.1f}s] Transmitting Frame {current_frame} selectively")

        yield env.timeout(1.0)

        if random.random() < LOSS_PROBABILITY:
            print(f"[Time {env.now:.1f}s] Frame {current_frame} LOST! Only retransmitting Frame {current_frame}")
        else:
            print(f"[Time {env.now:.1f}s] Individual ACK received for Frame {current_frame}")
            unacknowledged.pop(0)

    print(f"[Time {env.now:.1f}s] Selective Repeat complete! All {TOTAL_FRAMES} frames delivered.")

env = simpy.Environment()
env.process(selective_repeat_sender(env))
env.run()
