=============================================================================
TOPIC 18: SELECTIVE REPEAT (SR) ARQ
=============================================================================
Sliding window protocol where receiver buffers out-of-order frames and sends
individual ACKs. Sender only retransmits missing/lost frames. (Port: 6218)

HOW TO RUN:
1. Socket Demo (2 terminals):
   Terminal 1: python server.py
   Terminal 2: python client.py

2. SimPy Simulation:
   Terminal: python simpy_simulation.py
=============================================================================
