import socket

HOST = "127.0.0.1"
PORT = 6218
WINDOW_SIZE = 4

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_socket.bind((HOST, PORT))
server_socket.listen()
print(f"Selective Repeat Receiver running on {HOST}:{PORT}")

client_socket, client_address = server_socket.accept()
received_buffer = set()

while True:
    data = client_socket.recv(1024).decode().strip()
    if not data or data.lower() == "done":
        break

    frame_seq = int(data)
    received_buffer.add(frame_seq)
    print(f"Received Frame {frame_seq}. Buffered frames: {sorted(list(received_buffer))}")
    reply = f"ACK {frame_seq}"
    client_socket.sendall(reply.encode())

client_socket.close()
server_socket.close()
