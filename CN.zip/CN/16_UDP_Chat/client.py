import socket

SERVER_HOST = "127.0.0.1"
SERVER_PORT = 6216

client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
print("UDP Chat Client ready. Type 'exit' to quit.")

while True:
    msg = input("You: ").strip()
    client_socket.sendto(msg.encode(), (SERVER_HOST, SERVER_PORT))
    if msg.lower() == "exit":
        break

    data, server = client_socket.recvfrom(1024)
    reply = data.decode().strip()
    print("Server:", reply)
    if reply.lower() == "exit":
        break

client_socket.close()
