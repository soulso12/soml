import simpy

MESSAGES = [
    ("Client", "Hello via UDP!"),
    ("Server", "UDP message received!"),
    ("Client", "Is it fast?"),
    ("Server", "Yes, low latency connectionless."),
    ("Client", "exit")
]

def udp_chat_flow(env):
    for sender, msg in MESSAGES:
        yield env.timeout(0.3)
        print(f"[Time {env.now:.1f}s] {sender} -> Datagram: '{msg}'")
        if msg.lower() == "exit":
            print(f"[Time {env.now:.1f}s] Chat session ended.")
            break

env = simpy.Environment()
env.process(udp_chat_flow(env))
env.run()
