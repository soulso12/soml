import socket

HOST = "127.0.0.1"
PORT = 6216

server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_socket.bind((HOST, PORT))
print(f"UDP Chat Server listening on {HOST}:{PORT}")

while True:
    data, client_address = server_socket.recvfrom(1024)
    msg = data.decode().strip()
    if not msg or msg.lower() == "exit":
        print("Client disconnected.")
        break
    print(f"Client ({client_address[0]}:{client_address[1]}): {msg}")

    reply = input("Server reply: ").strip()
    server_socket.sendto(reply.encode(), client_address)
    if reply.lower() == "exit":
        break

server_socket.close()
