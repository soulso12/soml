=============================================================================
TOPIC 04: CHECKSUM ERROR DETECTION
=============================================================================

WHAT IS THIS TOPIC?
    A checksum detects accidental transmission errors. The sender computes a sum
    of the message bytes and sends it. The receiver recomputes the sum; if both
    match, no error occurred.

FILES IN THIS FOLDER:
    1. server.py            - Receiver on port 6204: Recomputes and verifies checksum.
    2. client.py            - Sender: Prompts for text, computes checksum, optional tamper test.
    3. simpy_simulation.py  - Simulates noisy channel corruption detection.

HOW TO RUN:
    Method 1: Socket Demo (requires 2 terminals)
        Terminal 1: python server.py
        Terminal 2: python client.py

    Method 2: SimPy Simulation (single terminal)
        Terminal:   python simpy_simulation.py
=============================================================================
