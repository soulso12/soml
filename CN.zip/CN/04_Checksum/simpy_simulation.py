import simpy
import random

random.seed(4)

TOTAL_PACKETS = 5
CORRUPTION_RATE = 0.25

def verify_packet(env, packet_id, receiver, results):
    with receiver.request() as req:
        yield req
        yield env.timeout(1.0)
        is_corrupt = random.random() < CORRUPTION_RATE
        status = "Corrupted" if is_corrupt else "Valid"
        results.append(status)
        print(f"[Time {env.now}s] Packet {packet_id} -> {status}")

env = simpy.Environment()
receiver = simpy.Resource(env, capacity=1)
results = []

for i in range(1, TOTAL_PACKETS + 1):
    env.process(verify_packet(env, i, receiver, results))

env.run()

print("Valid Packets:", results.count("Valid"))
print("Corrupted Packets:", results.count("Corrupted"))
