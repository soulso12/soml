import socket

HOST = "127.0.0.1"
PORT = 6204

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_socket.bind((HOST, PORT))
server_socket.listen()
print(f"Checksum Server running on {HOST}:{PORT}")

while True:
    client_socket, client_address = server_socket.accept()
    raw_packet = client_socket.recv(2048).decode().strip()
    print("Received packet:", raw_packet)

    try:
        message_body, received_checksum = raw_packet.rsplit("|", 1)
        computed_checksum = sum(message_body.encode()) % 256

        if computed_checksum == int(received_checksum):
            reply = "Valid: Checksum matched, no corruption."
        else:
            reply = "Error: Checksum mismatch, data corrupted!"
    except ValueError:
        reply = "Error: Invalid packet format"

    client_socket.sendall(reply.encode())
    client_socket.close()
