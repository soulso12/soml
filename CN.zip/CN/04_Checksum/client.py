import socket

SERVER_HOST = "127.0.0.1"
SERVER_PORT = 6204

msg = input("Enter message: ").strip() or "Hello"
checksum = sum(msg.encode()) % 256

corrupt = input("Corrupt message? (y/n): ").strip().lower()
if corrupt == "y":
    packet = f"{msg}X|{checksum}"
else:
    packet = f"{msg}|{checksum}"

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.settimeout(5.0)

try:
    client_socket.connect((SERVER_HOST, SERVER_PORT))
    client_socket.sendall(packet.encode())
    reply = client_socket.recv(1024).decode()
    print("Server Response:", reply)
except Exception as e:
    print("Error:", e)
finally:
    client_socket.close()
