import socket

SERVER_HOST = "127.0.0.1"
SERVER_PORT = 6211

status = input("Enter congestion status (e.g. cwnd=4, ssthresh=8): ").strip() or "cwnd=4, ssthresh=8"

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.settimeout(5.0)

try:
    client_socket.connect((SERVER_HOST, SERVER_PORT))
    client_socket.sendall(status.encode())
    reply = client_socket.recv(1024).decode()
    print("Server Response:", reply)
except Exception as e:
    print("Error:", e)
finally:
    client_socket.close()
