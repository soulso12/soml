import socket

HOST = "127.0.0.1"
PORT = 6211

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_socket.bind((HOST, PORT))
server_socket.listen()
print(f"Congestion Monitor Server running on {HOST}:{PORT}")

while True:
    client_socket, client_address = server_socket.accept()
    report = client_socket.recv(1024).decode().strip()
    print("Received congestion report:", report)

    reply = f"Server ACK for: {report}"
    client_socket.sendall(reply.encode())
    client_socket.close()
