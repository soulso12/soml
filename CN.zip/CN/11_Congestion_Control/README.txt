=============================================================================
TOPIC 11: TCP CONGESTION CONTROL
=============================================================================

WHAT IS THIS TOPIC?
    Congestion control avoids overwhelming network routers. TCP uses:
    1. Slow Start: Doubles cwnd each RTT until ssthresh.
    2. Congestion Avoidance: Increases cwnd by +1 each RTT (Additive Increase).
    3. Multiplicative Decrease: Halves ssthresh and resets cwnd upon packet loss.

FILES IN THIS FOLDER:
    1. server.py            - Monitor Server on port 6211: Logs client congestion state.
    2. client.py            - Client: Sends congestion window updates to server.
    3. simpy_simulation.py  - Simulates 12 rounds of TCP Reno (Slow Start & AIMD).

HOW TO RUN:
    Method 1: Socket Demo (requires 2 terminals)
        Terminal 1: python server.py
        Terminal 2: python client.py

    Method 2: SimPy Simulation (single terminal)
        Terminal:   python simpy_simulation.py
=============================================================================
