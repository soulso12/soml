import simpy
import random

random.seed(3)

ROUNDS = 12
THRESHOLD = 8
LOSS_PROBABILITY = 0.20

def reno(env):
    cwnd = 1
    ssthresh = THRESHOLD

    for r in range(1, ROUNDS + 1):
        yield env.timeout(1.0)

        if random.random() < LOSS_PROBABILITY:
            ssthresh = max(cwnd // 2, 1)
            cwnd = 1
            print(f"Round {r:02d}: Packet Loss! New ssthresh={ssthresh}, cwnd={cwnd}")
        else:
            if cwnd < ssthresh:
                cwnd = min(cwnd * 2, ssthresh)
                print(f"Round {r:02d}: Slow Start -> cwnd={cwnd}, ssthresh={ssthresh}")
            else:
                cwnd += 1
                print(f"Round {r:02d}: Congestion Avoidance -> cwnd={cwnd}, ssthresh={ssthresh}")

env = simpy.Environment()
env.process(reno(env))
env.run()
