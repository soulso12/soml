import socket

HOST = "127.0.0.1"
PORT = 6203

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_socket.bind((HOST, PORT))
server_socket.listen()
print(f"Stop-and-Wait Receiver running on {HOST}:{PORT}")

while True:
    client_socket, client_address = server_socket.accept()
    frame = client_socket.recv(1024).decode().strip()
    if frame:
        print("Received:", frame)
        reply = f"ACK for {frame}"
        client_socket.sendall(reply.encode())
    client_socket.close()
