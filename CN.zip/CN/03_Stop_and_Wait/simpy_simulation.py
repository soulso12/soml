import simpy
import random

random.seed(7)

TOTAL_FRAMES = 3
LOSS_PROBABILITY = 0.30

def sender(env):
    for frame_id in range(1, TOTAL_FRAMES + 1):
        attempt = 1
        start_time = env.now

        while True:
            print(f"[Time {env.now}s] Sending Frame {frame_id} (Attempt {attempt})")
            yield env.timeout(1.0)

            if random.random() < LOSS_PROBABILITY:
                print(f"Frame {frame_id} lost! Timeout triggered, retransmitting...")
                attempt += 1
            else:
                print(f"ACK received for Frame {frame_id} in {env.now - start_time}s")
                break

env = simpy.Environment()
env.process(sender(env))
env.run()
