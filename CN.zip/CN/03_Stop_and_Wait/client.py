import socket
import time

SERVER_HOST = "127.0.0.1"
SERVER_PORT = 6203

FRAMES = ["FRAME-1", "FRAME-2", "FRAME-3"]

for frame in FRAMES:
    print("Sending:", frame)
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.settimeout(3.0)

    try:
        client_socket.connect((SERVER_HOST, SERVER_PORT))
        client_socket.sendall(frame.encode())
        ack = client_socket.recv(1024).decode()
        print("Received:", ack)
    except Exception as e:
        print("Error:", e)
    finally:
        client_socket.close()

    time.sleep(1.0)

print("All frames transmitted.")
