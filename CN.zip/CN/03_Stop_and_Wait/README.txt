=============================================================================
TOPIC 03: STOP-AND-WAIT ARQ
=============================================================================

WHAT IS THIS TOPIC?
    Stop-and-Wait ARQ ensures reliable data transfer:
    Sender sends 1 frame, pauses and waits for receiver ACK.
    If ACK arrives -> send next frame.
    If timeout -> retransmit current frame.

FILES IN THIS FOLDER:
    1. server.py            - Receiver on port 6203: Receives frames and sends ACKs.
    2. client.py            - Sender: Transmits frames sequentially with wait-for-ACK.
    3. simpy_simulation.py  - Simulates frame transmission with timeouts and retries.

HOW TO RUN:
    Method 1: Socket Demo (requires 2 terminals)
        Terminal 1: python server.py
        Terminal 2: python client.py

    Method 2: SimPy Simulation (single terminal)
        Terminal:   python simpy_simulation.py
=============================================================================
