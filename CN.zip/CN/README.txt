=============================================================================
COMPUTER NETWORKS (CN) LAB PRACTICE PACK - BEGINNER'S GUIDE
=============================================================================
This repository contains 20 practical computer network exercises.
All programs are written with clean, beginner-friendly logic, direct execution
without main functions, and no comment clutter.

-----------------------------------------------------------------------------
TOPIC DIRECTORY & PORT INDEX:
-----------------------------------------------------------------------------
  01_ARP                  (Port: 6201) - Address Resolution Protocol (IP to MAC)
  02_DNS                  (Port: 6202) - Domain Name System (Domain to IP)
  03_Stop_and_Wait        (Port: 6203) - Stop-and-Wait ARQ Protocol (ACK & Retries)
  04_Checksum             (Port: 6204) - 8-Bit Checksum Error Detection
  05_Bit_Stuffing         (Port: 6205) - Bit Stuffing (Framing) & CSMA/CA Backoff
  06_Routing              (Port: 6206) - IP Routing & Longest Prefix Matching (LPM)
  07_UDP                  (Port: 6207) - UDP Datagram Socket & Packet Loss Demo
  08_TCP_Multiclient      (Port: 6208) - Multi-Client Concurrent TCP Server (Threads)
  09_Subnetting           (Port: 6209) - IPv4 CIDR Subnet Calculator (Mask, Range)
  10_Flow_Control         (Port: 6210) - TCP Flow Control (Sliding Window Protocol)
  11_Congestion_Control   (Port: 6211) - TCP Congestion Control (Slow Start & AIMD)
  12_CDMA                 (Port: 6212) - Code Division Multiple Access (Orthogonal Codes)
  13_Wireless_IoT         (Port: 6213) - Wireless IoT Sensor Gateway (WiFi/BLE/Zigbee)
  14_Network_Performance  (Port: 6214) - RTT Measurement & M/M/1 Queuing Latency
  15_TCP_Chat             (Port: 6215) - Two-Way Interactive TCP Chat
  16_UDP_Chat             (Port: 6216) - Two-Way Interactive Connectionless UDP Chat
  17_Go_Back_N            (Port: 6217) - Go-Back-N (GBN) Sliding Window ARQ
  18_Selective_Repeat     (Port: 6218) - Selective Repeat (SR) Individual ACK ARQ
  19_CSMA                 (Port: 6219) - Carrier Sense Multiple Access (Sensing & Backoff)
  20_Packet_Routing       (Port: 6220) - Hop-by-Hop Packet Routing & TTL Decrementing

-----------------------------------------------------------------------------
FILES IN EACH FOLDER:
-----------------------------------------------------------------------------
  - server.py            : Socket server listening on localhost (127.0.0.1:port)
  - client.py            : Socket client with user-friendly input prompts
  - simpy_simulation.py  : Standalone discrete-event simulation (models delays & loss)
  - README.txt           : Specific instructions and sample inputs for the topic

-----------------------------------------------------------------------------
HOW TO RUN:
-----------------------------------------------------------------------------
1. Socket Client-Server Programs (Requires 2 terminal windows):
   - Terminal 1: Navigate to the topic folder and start the server:
         cd 15_TCP_Chat
         python server.py
   - Terminal 2: In the same folder, run the client:
         cd 15_TCP_Chat
         python client.py

2. SimPy Simulations (Only requires 1 terminal window):
   - Run directly:
         python 15_TCP_Chat/simpy_simulation.py
=============================================================================
