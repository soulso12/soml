import socket

SERVER_HOST = "127.0.0.1"
SERVER_PORT = 6215

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect((SERVER_HOST, SERVER_PORT))
print("Connected to TCP Chat Server. Type 'exit' to quit.")

while True:
    message = input("You: ").strip()
    client_socket.sendall(message.encode())
    if message.lower() == "exit":
        break

    reply = client_socket.recv(1024).decode().strip()
    if not reply or reply.lower() == "exit":
        print("Server ended chat.")
        break
    print("Server:", reply)

client_socket.close()
