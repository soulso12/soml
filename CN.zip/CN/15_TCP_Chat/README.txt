=============================================================================
TOPIC 15: TCP CHAT
=============================================================================
Two-way interactive chat using TCP socket (Port: 6215).

HOW TO RUN:
1. Socket Demo (2 terminals):
   Terminal 1: python server.py
   Terminal 2: python client.py
   (Type messages back and forth. Type 'exit' to end chat.)

2. SimPy Simulation:
   Terminal: python simpy_simulation.py
=============================================================================
