import simpy

MESSAGES = [
    ("Client", "Hello Server"),
    ("Server", "Hi Client, how are you?"),
    ("Client", "I am testing TCP Chat"),
    ("Server", "Received loud and clear!"),
    ("Client", "exit")
]

def chat_exchange(env):
    for sender, msg in MESSAGES:
        yield env.timeout(0.5)
        print(f"[Time {env.now:.1f}s] {sender}: {msg}")
        if msg.lower() == "exit":
            print(f"[Time {env.now:.1f}s] Connection terminated cleanly.")
            break

env = simpy.Environment()
env.process(chat_exchange(env))
env.run()
