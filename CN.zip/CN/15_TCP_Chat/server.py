import socket

HOST = "127.0.0.1"
PORT = 6215

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_socket.bind((HOST, PORT))
server_socket.listen()
print(f"TCP Chat Server waiting for connection on {HOST}:{PORT}")

client_socket, client_address = server_socket.accept()
print(f"Connected with {client_address}")

while True:
    message = client_socket.recv(1024).decode().strip()
    if not message or message.lower() == "exit":
        print("Client ended chat.")
        break
    print("Client:", message)

    reply = input("Server reply: ").strip()
    client_socket.sendall(reply.encode())
    if reply.lower() == "exit":
        break

client_socket.close()
server_socket.close()
