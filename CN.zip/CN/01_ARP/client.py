import socket

SERVER_HOST = "127.0.0.1"
SERVER_PORT = 6201

target_ip = input("Enter IPv4 address to lookup (e.g. 192.168.1.10): ").strip()

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.settimeout(5.0)

try:
    client_socket.connect((SERVER_HOST, SERVER_PORT))
    client_socket.sendall(target_ip.encode())
    response = client_socket.recv(1024).decode()
    print("Server Response:", response)
except Exception as e:
    print("Error:", e)
finally:
    client_socket.close()
