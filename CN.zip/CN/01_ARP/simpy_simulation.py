import simpy
import ipaddress

ARP_TABLE = {
    "192.168.1.10": "AA:BB:CC:DD:EE:10",
    "192.168.1.20": "52:54:00:12:34:56"
}

QUERIES = [
    "192.168.1.10",
    "192.168.1.99",
    "bad-ip",
    "192.168.1.20"
]

def request(env, request_id, ip_str, server, stats):
    arrival = env.now
    with server.request() as req:
        yield req
        yield env.timeout(1.0)
        try:
            valid_ip = str(ipaddress.IPv4Address(ip_str))
            mac = ARP_TABLE.get(valid_ip, "MAC Not Found")
        except ValueError:
            mac = "Invalid IP"
        finish = env.now
        stats.append(finish - arrival)
        print(f"Device {request_id} ({ip_str}) -> {mac} | Turnaround: {finish - arrival}s")

env = simpy.Environment()
server = simpy.Resource(env, capacity=1)
stats = []

for i, ip in enumerate(QUERIES, 1):
    env.process(request(env, i, ip, server, stats))

env.run()

print("Average Response Time:", sum(stats) / len(stats))
