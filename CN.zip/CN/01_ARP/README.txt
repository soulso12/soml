=============================================================================
TOPIC 01: ADDRESS RESOLUTION PROTOCOL (ARP)
=============================================================================

WHAT IS THIS TOPIC?
    ARP maps an IPv4 address (e.g. 192.168.1.10) to a Physical MAC address
    (e.g. AA:BB:CC:DD:EE:10).

FILES IN THIS FOLDER:
    1. server.py            - Listens on port 6201 and resolves IP -> MAC.
    2. client.py            - Connects to server, inputs IP, displays MAC reply.
    3. simpy_simulation.py  - Simulates ARP server queue latency using SimPy.

HOW TO RUN:
    Method 1: Socket Demo (requires 2 terminals)
        Terminal 1: python server.py
        Terminal 2: python client.py
        (Enter: 192.168.1.10)

    Method 2: SimPy Simulation (single terminal)
        Terminal:   python simpy_simulation.py
=============================================================================
