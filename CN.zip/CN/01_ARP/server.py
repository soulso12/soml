import socket
import ipaddress

HOST = "127.0.0.1"
PORT = 6201

ARP_TABLE = {
    "192.168.1.1": "00:1A:2B:3C:4D:01",
    "192.168.1.10": "AA:BB:CC:DD:EE:10",
    "192.168.1.11": "AA:BB:CC:DD:EE:11",
    "192.168.1.20": "52:54:00:12:34:56"
}

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_socket.bind((HOST, PORT))
server_socket.listen()
print(f"ARP Server running on {HOST}:{PORT}")

while True:
    client_socket, client_address = server_socket.accept()
    raw_data = client_socket.recv(1024).decode().strip()
    print("Received IP:", raw_data)

    try:
        valid_ip = str(ipaddress.IPv4Address(raw_data))
        if valid_ip in ARP_TABLE:
            reply = f"MAC: {ARP_TABLE[valid_ip]}"
        else:
            reply = "IP not found in ARP table"
    except ValueError:
        reply = "Invalid IPv4 address"

    client_socket.sendall(reply.encode())
    client_socket.close()
