import socket

HOST = "127.0.0.1"
PORT = 6220

FORWARDING_TABLE = {
    "10.0.0.":    ("192.168.10.1", "eth1 (Intranet Core)"),
    "172.16.":    ("192.168.20.1", "eth2 (Branch Office)"),
    "192.168.1.": ("192.168.1.1",  "eth0 (Local Subnet)")
}
DEFAULT_GATEWAY = ("100.64.0.1", "eth3 (Internet WAN)")

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_socket.bind((HOST, PORT))
server_socket.listen()
print(f"Packet Routing Server running on {HOST}:{PORT}")

while True:
    client_socket, client_address = server_socket.accept()
    raw_packet = client_socket.recv(1024).decode().strip()
    print("Received packet header:", raw_packet)

    try:
        parts = raw_packet.split("|")
        src_ip = parts[0]
        dest_ip = parts[1]
        ttl = int(parts[2])
        payload = parts[3]

        ttl -= 1
        if ttl <= 0:
            reply = "ROUTING ERROR: Packet dropped (TTL expired)"
        else:
            next_hop = DEFAULT_GATEWAY
            for prefix, route in FORWARDING_TABLE.items():
                if dest_ip.startswith(prefix):
                    next_hop = route
                    break

            reply = (
                f"FORWARDED: Packet from {src_ip} to {dest_ip}\n"
                f"Payload: '{payload}'\n"
                f"Next Hop Gateway: {next_hop[0]}\n"
                f"Outgoing Interface: {next_hop[1]}\n"
                f"Remaining TTL: {ttl}"
            )
    except Exception:
        reply = "ROUTING ERROR: Invalid packet format. Expected: src|dest|ttl|payload"

    client_socket.sendall(reply.encode())
    client_socket.close()
