import simpy

HOPS = [
    ("Host-A", "Router-1", 0.5),
    ("Router-1", "Router-2", 0.8),
    ("Router-2", "Router-3", 0.7),
    ("Router-3", "Host-B", 0.4)
]

def packet_route(env, packet_id, dest_ip, initial_ttl):
    ttl = initial_ttl
    print(f"\n[Time {env.now:.1f}s] Packet {packet_id} generated for {dest_ip} (TTL={ttl})")

    for src_hop, next_hop, delay in HOPS:
        yield env.timeout(delay)
        ttl -= 1
        print(f"[Time {env.now:.1f}s] Hop: {src_hop} -> {next_hop} | Remaining TTL={ttl}")
        if ttl <= 0:
            print(f"[Time {env.now:.1f}s] Packet {packet_id} DROPPED (TTL Expired at {next_hop})")
            return

    print(f"[Time {env.now:.1f}s] Packet {packet_id} successfully DELIVERED to destination {dest_ip}!")

env = simpy.Environment()

env.process(packet_route(env, 1, "10.0.1.5", initial_ttl=64))
env.process(packet_route(env, 2, "172.16.2.1", initial_ttl=2))

env.run()
