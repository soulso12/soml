import socket

SERVER_HOST = "127.0.0.1"
SERVER_PORT = 6220

src_ip = "192.168.1.100"
dest_ip = input("Enter destination IP (e.g. 10.0.1.5 or 8.8.8.8): ").strip() or "10.0.1.5"
ttl = input("Enter TTL (e.g. 64): ").strip() or "64"
payload = input("Enter packet payload: ").strip() or "PingData"

packet_str = f"{src_ip}|{dest_ip}|{ttl}|{payload}"

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect((SERVER_HOST, SERVER_PORT))
client_socket.sendall(packet_str.encode())

response = client_socket.recv(2048).decode().strip()
print("\nRouter Response:\n" + response)

client_socket.close()
