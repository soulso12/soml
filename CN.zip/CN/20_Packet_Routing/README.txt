=============================================================================
TOPIC 20: PACKET ROUTING
=============================================================================
Hop-by-hop packet forwarding with next-hop lookup and TTL decrementing. (Port: 6220)

HOW TO RUN:
1. Socket Demo (2 terminals):
   Terminal 1: python server.py
   Terminal 2: python client.py

2. SimPy Simulation:
   Terminal: python simpy_simulation.py
=============================================================================
