import socket

bits = input("Enter exactly 8 bits (e.g. 01111110): ").strip() or "01111110"

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.settimeout(5.0)

try:
    client_socket.connect(("127.0.0.1", 6205))
    client_socket.sendall(bits.encode())
    reply = client_socket.recv(2048).decode()
    print("Server Response:\n", reply)
except Exception as e:
    print("Error:", e)
finally:
    client_socket.close()
