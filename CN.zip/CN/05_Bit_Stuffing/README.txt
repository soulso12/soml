=============================================================================
TOPIC 05: BIT STUFFING AND CSMA/CA
=============================================================================

WHAT IS THIS TOPIC?
    1. Bit Stuffing: Data Link framing rule where a '0' is inserted after every
       five consecutive 1s ('11111') to prevent user data from mimicking the 
       frame FLAG ('01111110').
    2. CSMA/CA: Wireless channel protocol where nodes sense the channel before
       sending and use random exponential backoff when the medium is busy.

FILES IN THIS FOLDER:
    1. server.py            - Receiver on port 6205: Shows stuffing, framing, and destuffing.
    2. client.py            - Sender: Prompts for 8 bits (e.g. 01111110) and transmits.
    3. simpy_simulation.py  - Simulates 5 wireless sensors competing using CSMA/CA.

HOW TO RUN:
    Method 1: Socket Demo (requires 2 terminals)
        Terminal 1: python server.py
        Terminal 2: python client.py
        (Enter: 01111110)

    Method 2: SimPy Simulation (single terminal)
        Terminal:   python simpy_simulation.py
=============================================================================
