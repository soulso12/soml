import simpy
import random

random.seed(10)

NODES = 5
CW_MIN = 4
CW_MAX = 16
SLOT = 0.001
MAX_RETRIES = 4

def node(env, name, channel, stats):
    for pkt in range(1, 6):
        yield env.timeout(random.expovariate(1.0 / 0.004))
        attempts = 0
        cw = CW_MIN

        while attempts <= MAX_RETRIES:
            backoff = random.randint(0, cw - 1)
            yield env.timeout(backoff * SLOT)

            if channel.count == 0:
                with channel.request() as req:
                    yield req
                    yield env.timeout(0.003)
                    stats["success"] += 1
                    print(f"[{env.now*1000:.1f}ms] {name} packet {pkt}: SUCCESS after {attempts} retries")
                break
            else:
                stats["busy"] += 1
                attempts += 1
                cw = min(cw * 2, CW_MAX)

        if attempts > MAX_RETRIES:
            stats["dropped"] += 1
            print(f"[{env.now*1000:.1f}ms] {name} packet {pkt}: DROPPED")

env = simpy.Environment()
channel = simpy.Resource(env, capacity=1)
stats = {"success": 0, "busy": 0, "dropped": 0}

for i in range(NODES):
    env.process(node(env, f"Sensor-{i+1}", channel, stats))

env.run()

print("Successful:", stats["success"])
print("Busy/Collisions:", stats["busy"])
print("Dropped:", stats["dropped"])
