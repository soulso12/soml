import socket

FLAG = "01111110"

def stuff(bits):
    out = []
    ones = 0
    for b in bits:
        out.append(b)
        if b == "1":
            ones += 1
            if ones == 5:
                out.append("0")
                ones = 0
        else:
            ones = 0
    return "".join(out)

def destuff(bits):
    out = []
    ones = 0
    i = 0
    while i < len(bits):
        b = bits[i]
        out.append(b)
        i += 1
        if b == "1":
            ones += 1
            if ones == 5:
                if i < len(bits) and bits[i] == "0":
                    i += 1
                ones = 0
        else:
            ones = 0
    return "".join(out)

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_socket.bind(("127.0.0.1", 6205))
server_socket.listen()
print("Framing Server running on 127.0.0.1:6205")

while True:
    client_socket, client_address = server_socket.accept()
    bits = client_socket.recv(1024).decode().strip()
    print("Received bits:", bits)

    if len(bits) != 8 or any(b not in "01" for b in bits):
        reply = "Error: Input must be exactly 8 bits (0s and 1s)"
    else:
        stuffed = stuff(bits)
        frame = FLAG + stuffed + FLAG
        body = frame[len(FLAG):-len(FLAG)]
        destuffed = destuff(body)
        reply = f"Stuffed: {stuffed} | Frame: {frame} | Destuffed: {destuffed} | Match: {destuffed == bits}"

    client_socket.sendall(reply.encode())
    client_socket.close()
