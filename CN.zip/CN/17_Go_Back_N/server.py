import socket

HOST = "127.0.0.1"
PORT = 6217

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_socket.bind((HOST, PORT))
server_socket.listen()
print(f"Go-Back-N Receiver running on {HOST}:{PORT}")

client_socket, client_address = server_socket.accept()
expected_frame = 0

while True:
    data = client_socket.recv(1024).decode().strip()
    if not data or data.lower() == "done":
        break

    frame_seq = int(data)
    print(f"Received Frame {frame_seq} (Expecting {expected_frame})")

    if frame_seq == expected_frame:
        print(f"Frame {frame_seq} accepted.")
        expected_frame += 1
        reply = f"ACK {expected_frame}"
    else:
        print(f"Frame {frame_seq} discarded (Out of order).")
        reply = f"ACK {expected_frame}"

    client_socket.sendall(reply.encode())

client_socket.close()
server_socket.close()
