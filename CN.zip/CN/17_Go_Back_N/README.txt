=============================================================================
TOPIC 17: GO-BACK-N (GBN) ARQ
=============================================================================
Sliding window protocol where receiver only accepts frames in-order.
If a frame is lost, all frames in the window starting from the lost frame
are retransmitted. (Port: 6217)

HOW TO RUN:
1. Socket Demo (2 terminals):
   Terminal 1: python server.py
   Terminal 2: python client.py

2. SimPy Simulation:
   Terminal: python simpy_simulation.py
=============================================================================
