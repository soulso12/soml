import socket
import time

SERVER_HOST = "127.0.0.1"
SERVER_PORT = 6217
WINDOW_SIZE = 4
TOTAL_FRAMES = 8

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect((SERVER_HOST, SERVER_PORT))
print(f"Connected to GBN Receiver. Sending {TOTAL_FRAMES} frames with Window={WINDOW_SIZE}.")

base = 0
next_seq = 0

while base < TOTAL_FRAMES:
    while next_seq < base + WINDOW_SIZE and next_seq < TOTAL_FRAMES:
        print(f"Sending Frame {next_seq}")
        client_socket.sendall(str(next_seq).encode())
        next_seq += 1
        time.sleep(0.3)

    response = client_socket.recv(1024).decode().strip()
    print("Received:", response)
    ack_num = int(response.split()[1])

    if ack_num > base:
        base = ack_num
        print(f"Window slides forward. Base is now {base}")
    else:
        print(f"Duplicate ACK received. Retransmitting window from {base}")
        next_seq = base

client_socket.sendall(b"done")
client_socket.close()
print("All frames delivered.")
