import simpy
import random

random.seed(5)

WINDOW_SIZE = 4
TOTAL_FRAMES = 8
LOSS_PROBABILITY = 0.25

def gbn_sender(env):
    base = 0
    next_seq = 0

    while base < TOTAL_FRAMES:
        while next_seq < base + WINDOW_SIZE and next_seq < TOTAL_FRAMES:
            print(f"[Time {env.now:.1f}s] Sent Frame {next_seq}")
            next_seq += 1

        yield env.timeout(1.0)

        if random.random() < LOSS_PROBABILITY:
            print(f"[Time {env.now:.1f}s] Timeout! Frame {base} lost! Go-Back-N to {base}")
            next_seq = base
        else:
            base += 1
            print(f"[Time {env.now:.1f}s] ACK received! Window slides to {base}")

    print(f"[Time {env.now:.1f}s] GBN Simulation finished: All {TOTAL_FRAMES} frames delivered.")

env = simpy.Environment()
env.process(gbn_sender(env))
env.run()
