import simpy

CODE_A = [1,  1, 1,  1]
CODE_B = [1, -1, 1, -1]

encoded_signals = {}

def transmitter(env, name, bit_val, code):
    bipolar = 1 if bit_val == 1 else -1
    chip_signal = [bipolar * c for c in code]
    encoded_signals[name] = chip_signal
    print(f"[Time {env.now}s] {name} (Bit={bit_val}) -> Signal: {chip_signal}")
    yield env.timeout(1.0)

env = simpy.Environment()

env.process(transmitter(env, "Transmitter-A", 1, CODE_A))
env.process(transmitter(env, "Transmitter-B", 0, CODE_B))

env.run()

sig_a = encoded_signals["Transmitter-A"]
sig_b = encoded_signals["Transmitter-B"]
combined = [sig_a[i] + sig_b[i] for i in range(4)]

dot_a = sum(combined[i] * CODE_A[i] for i in range(4))
dot_b = sum(combined[i] * CODE_B[i] for i in range(4))

dec_a = 1 if dot_a > 0 else 0
dec_b = 1 if dot_b > 0 else 0

print("Combined Signal:", combined)
print("Decoded A:", dec_a)
print("Decoded B:", dec_b)
