import socket

SERVER_HOST = "127.0.0.1"
SERVER_PORT = 6212

bit_a = input("Enter bit for User A (0 or 1): ").strip() or "1"
bit_b = input("Enter bit for User B (0 or 1): ").strip() or "0"

payload = f"{bit_a},{bit_b}"

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.settimeout(5.0)

try:
    client_socket.connect((SERVER_HOST, SERVER_PORT))
    client_socket.sendall(payload.encode())
    reply = client_socket.recv(1024).decode()
    print("Server Response:", reply)
except Exception as e:
    print("Error:", e)
finally:
    client_socket.close()
