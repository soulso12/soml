import socket

HOST = "127.0.0.1"
PORT = 6212

CODE_A = [1,  1, 1,  1]
CODE_B = [1, -1, 1, -1]

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_socket.bind((HOST, PORT))
server_socket.listen()
print(f"CDMA Server running on {HOST}:{PORT}")

while True:
    client_socket, client_address = server_socket.accept()
    raw_input = client_socket.recv(1024).decode().strip()
    print("Received bits:", raw_input)

    try:
        parts = raw_input.split(",")
        bit_a = int(parts[0].strip())
        bit_b = int(parts[1].strip())

        val_a = 1 if bit_a == 1 else -1
        val_b = 1 if bit_b == 1 else -1

        sig_a = [val_a * c for c in CODE_A]
        sig_b = [val_b * c for c in CODE_B]
        combined = [sig_a[i] + sig_b[i] for i in range(4)]

        dot_a = sum(combined[i] * CODE_A[i] for i in range(4))
        dot_b = sum(combined[i] * CODE_B[i] for i in range(4))

        dec_a = 1 if dot_a > 0 else 0
        dec_b = 1 if dot_b > 0 else 0

        reply = f"Combined: {combined} | Decoded A: {dec_a} | Decoded B: {dec_b}"
    except Exception:
        reply = "Error: Input format must be 'bitA,bitB' (e.g. 1,0)"

    client_socket.sendall(reply.encode())
    client_socket.close()
