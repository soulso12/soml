=============================================================================
TOPIC 12: CDMA (CODE DIVISION MULTIPLE ACCESS)
=============================================================================

WHAT IS THIS TOPIC?
    CDMA enables multiple transmitters to send data over the SAME frequency
    channel at the SAME time using orthogonal chipping codes (Walsh codes).
    At the receiver, inner dot product extracts each user's original bit cleanly.

FILES IN THIS FOLDER:
    1. server.py            - Receiver on port 6212: Demodulates composite CDMA signals.
    2. client.py            - Client: Sends bits for User A and User B (e.g. 1,0).
    3. simpy_simulation.py  - Simulates parallel air transmission and separation.

HOW TO RUN:
    Method 1: Socket Demo (requires 2 terminals)
        Terminal 1: python server.py
        Terminal 2: python client.py
        (Enter: 1 for A, 0 for B)

    Method 2: SimPy Simulation (single terminal)
        Terminal:   python simpy_simulation.py
=============================================================================
