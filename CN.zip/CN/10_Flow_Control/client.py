import socket
import time

SERVER_HOST = "127.0.0.1"
SERVER_PORT = 6210
WINDOW_SIZE = 4

all_chunks = [f"Chunk-{i}" for i in range(1, 11)]
sent = 0

while sent < len(all_chunks):
    batch = all_chunks[sent : sent + WINDOW_SIZE]
    batch_str = " ".join(batch)
    print("Transmitting window batch:", batch)

    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.settimeout(5.0)

    try:
        client_socket.connect((SERVER_HOST, SERVER_PORT))
        client_socket.sendall(batch_str.encode())
        ack = client_socket.recv(1024).decode()
        print("Server Response:", ack)
        sent += len(batch)
    except Exception as e:
        print("Error:", e)
        break
    finally:
        client_socket.close()

    time.sleep(1.0)

print("All chunks transmitted.")
