import simpy

TOTAL_PACKETS = 10
WINDOW_SIZE = 4

def sender(env):
    sent = 0
    while sent < TOTAL_PACKETS:
        count = min(WINDOW_SIZE, TOTAL_PACKETS - sent)
        print(f"[Time {env.now}s] Sending {count} packet(s)")
        yield env.timeout(1.0)
        sent += count
        print(f"[Time {env.now}s] ACK received! Total acknowledged: {sent}/{TOTAL_PACKETS}")

env = simpy.Environment()
env.process(sender(env))
env.run()
