import socket

HOST = "127.0.0.1"
PORT = 6210
WINDOW_SIZE = 4

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_socket.bind((HOST, PORT))
server_socket.listen()
print(f"Flow Control Receiver running on {HOST}:{PORT}")

while True:
    client_socket, client_address = server_socket.accept()
    raw_data = client_socket.recv(4096).decode().strip()
    if raw_data:
        chunks = raw_data.split()
        print(f"Received {len(chunks)} chunks: {chunks}")
        reply = f"ACK: Received {len(chunks)} chunks (Window Size: {WINDOW_SIZE})"
        client_socket.sendall(reply.encode())
    client_socket.close()
