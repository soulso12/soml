=============================================================================
TOPIC 10: TCP FLOW CONTROL (SLIDING WINDOW)
=============================================================================

WHAT IS THIS TOPIC?
    Flow control prevents the sender from sending data faster than the receiver
    can process. The receiver announces its buffer window size (e.g. 4 chunks).
    The sender transmits up to 4 chunks, pauses for an ACK, and then slides its
    window forward to send the next batch.

FILES IN THIS FOLDER:
    1. server.py            - Receiver on port 6210: Advertises window size = 4.
    2. client.py            - Sender: Transmits 10 chunks in window batches of 4.
    3. simpy_simulation.py  - Simulates sliding window timing and ACK progression.

HOW TO RUN:
    Method 1: Socket Demo (requires 2 terminals)
        Terminal 1: python server.py
        Terminal 2: python client.py

    Method 2: SimPy Simulation (single terminal)
        Terminal:   python simpy_simulation.py
=============================================================================
