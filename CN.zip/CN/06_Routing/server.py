import socket
import ipaddress

HOST = "127.0.0.1"
PORT = 6206

ROUTING_TABLE = [
    ("192.168.1.0/24", "eth0 (LAN)"),
    ("10.0.0.0/8",      "eth1 (Corporate)"),
    ("0.0.0.0/0",       "default (Internet Gateway)")
]

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_socket.bind((HOST, PORT))
server_socket.listen()
print(f"Routing Server running on {HOST}:{PORT}")

while True:
    client_socket, client_address = server_socket.accept()
    raw_ip = client_socket.recv(1024).decode().strip()
    print("Received IP to route:", raw_ip)

    try:
        dest_ip = ipaddress.ip_address(raw_ip)
        matches = []
        for cidr, iface in ROUTING_TABLE:
            net = ipaddress.ip_network(cidr)
            if dest_ip in net:
                matches.append((net, iface))

        best_net, best_iface = max(matches, key=lambda x: x[0].prefixlen)
        reply = f"Route {dest_ip} via {best_iface} (Matched {best_net})"
    except ValueError:
        reply = "Error: Invalid IPv4 address"

    client_socket.sendall(reply.encode())
    client_socket.close()
