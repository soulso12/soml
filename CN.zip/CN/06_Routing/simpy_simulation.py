import simpy
import ipaddress

ROUTING_TABLE = [
    ("192.168.1.0/24", "eth0", 1.0),
    ("10.0.0.0/8",      "eth1", 2.0),
    ("0.0.0.0/0",       "default", 3.0)
]

PACKETS = [
    "192.168.1.55",
    "10.50.2.1",
    "8.8.8.8",
    "bad-ip"
]

def packet(env, pkt_id, ip_str, router):
    arrival = env.now
    with router.request() as req:
        yield req
        try:
            dest = ipaddress.ip_address(ip_str)
            matches = [(ipaddress.ip_network(c), iface, d) for c, iface, d in ROUTING_TABLE if dest in ipaddress.ip_network(c)]
            best = max(matches, key=lambda x: x[0].prefixlen)
            yield env.timeout(best[2])
            status = f"Routed via {best[1]}"
        except ValueError:
            yield env.timeout(0.5)
            status = "Dropped (Invalid IP)"

        print(f"[Time {env.now}s] Packet {pkt_id} ({ip_str}) -> {status} | Turnaround: {env.now - arrival}s")

env = simpy.Environment()
router = simpy.Resource(env, capacity=1)

for i, ip in enumerate(PACKETS, 1):
    env.process(packet(env, i, ip, router))

env.run()
