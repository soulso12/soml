import socket

SERVER_HOST = "127.0.0.1"
SERVER_PORT = 6206

dest_ip = input("Enter destination IP (e.g. 192.168.1.50): ").strip() or "192.168.1.50"

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.settimeout(5.0)

try:
    client_socket.connect((SERVER_HOST, SERVER_PORT))
    client_socket.sendall(dest_ip.encode())
    reply = client_socket.recv(1024).decode()
    print("Server Response:", reply)
except Exception as e:
    print("Error:", e)
finally:
    client_socket.close()
