=============================================================================
TOPIC 06: IP ROUTING (LONGEST PREFIX MATCH)
=============================================================================

WHAT IS THIS TOPIC?
    Routers inspect the destination IP address of incoming packets and forward
    them through the matching interface with the longest subnet mask (prefix).

FILES IN THIS FOLDER:
    1. server.py            - Router on port 6206: Evaluates destination IP using LPM.
    2. client.py            - Sender: Prompts for destination IP and requests route.
    3. simpy_simulation.py  - Simulates router forwarding queues and interface latencies.

HOW TO RUN:
    Method 1: Socket Demo (requires 2 terminals)
        Terminal 1: python server.py
        Terminal 2: python client.py
        (Try: 192.168.1.50 or 10.5.2.1 or 8.8.8.8)

    Method 2: SimPy Simulation (single terminal)
        Terminal:   python simpy_simulation.py
=============================================================================
