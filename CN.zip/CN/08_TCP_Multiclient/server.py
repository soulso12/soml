import socket
import threading

HOST = "127.0.0.1"
PORT = 6208

def handle_client(client_socket, client_address):
    msg = client_socket.recv(1024).decode().strip()
    print("Message from", client_address, ":", msg)
    reply = f"Server processed: {msg}"
    client_socket.sendall(reply.encode())
    client_socket.close()

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_socket.bind((HOST, PORT))
server_socket.listen(10)
print(f"Multi-Client TCP Server running on {HOST}:{PORT}")

while True:
    client_socket, client_address = server_socket.accept()
    thread = threading.Thread(target=handle_client, args=(client_socket, client_address), daemon=True)
    thread.start()
