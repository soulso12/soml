import simpy

CLIENT_JOBS = [
    ("Client-1", 2.0),
    ("Client-2", 1.0),
    ("Client-3", 3.0),
    ("Client-4", 2.0),
    ("Client-5", 1.0)
]

def client(env, name, server, duration, stats):
    arrival = env.now
    with server.request() as req:
        yield req
        yield env.timeout(duration)
        finish = env.now
        stats.append(finish - arrival)
        print(f"[Time {finish}s] {name} finished (Turnaround: {finish - arrival}s)")

env = simpy.Environment()
server = simpy.Resource(env, capacity=2)
stats = []

for name, duration in CLIENT_JOBS:
    env.process(client(env, name, server, duration, stats))

env.run()

print("Average Turnaround:", sum(stats) / len(stats))
