import socket

SERVER_HOST = "127.0.0.1"
SERVER_PORT = 6208

name = input("Enter client name: ").strip() or "Client-A"
msg = input("Enter message: ").strip() or "Hello"

payload = f"[{name}]: {msg}"

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.settimeout(5.0)

try:
    client_socket.connect((SERVER_HOST, SERVER_PORT))
    client_socket.sendall(payload.encode())
    reply = client_socket.recv(1024).decode()
    print("Server Response:", reply)
except Exception as e:
    print("Error:", e)
finally:
    client_socket.close()
