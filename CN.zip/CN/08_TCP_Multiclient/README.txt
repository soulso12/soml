=============================================================================
TOPIC 08: MULTI-CLIENT TCP SERVER
=============================================================================

WHAT IS THIS TOPIC?
    A multi-client TCP server uses threading to handle multiple simultaneous
    connections without blocking new incoming clients.

FILES IN THIS FOLDER:
    1. server.py            - Multi-threaded server on port 6208. Spawns threads per client.
    2. client.py            - Client sending messages. You can launch multiple clients.
    3. simpy_simulation.py  - Simulates a dual-worker server processing multiple clients.

HOW TO RUN:
    Method 1: Socket Demo (open 3 terminals to test concurrency!)
        Terminal 1: python server.py
        Terminal 2: python client.py
        Terminal 3: python client.py

    Method 2: SimPy Simulation (single terminal)
        Terminal:   python simpy_simulation.py
=============================================================================
