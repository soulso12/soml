import simpy

REQUESTS = [
    ("Request-1", 1.0),
    ("Request-2", 2.0),
    ("Request-3", 1.0),
    ("Request-4", 3.0),
    ("Request-5", 2.0)
]

def request_job(env, name, duration, server, stats):
    arrival = env.now
    with server.request() as req:
        yield req
        yield env.timeout(duration)
        turnaround = env.now - arrival
        stats.append(turnaround)
        print(f"[Time {env.now}s] {name} completed (Turnaround: {turnaround}s)")

env = simpy.Environment()
server = simpy.Resource(env, capacity=1)
stats = []

for name, duration in REQUESTS:
    env.process(request_job(env, name, duration, server, stats))

env.run()

print("Average Turnaround:", sum(stats) / len(stats))
