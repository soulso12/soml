import socket
import time

HOST = "127.0.0.1"
PORT = 6214

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_socket.bind((HOST, PORT))
server_socket.listen()
print(f"Performance Benchmark Server running on {HOST}:{PORT}")

while True:
    client_socket, client_address = server_socket.accept()
    request_data = client_socket.recv(1024).decode().strip()
    print("Processing request:", request_data)

    start = time.time()
    time.sleep(1.0)
    duration = time.time() - start

    reply = f"Processed '{request_data}' in {duration:.3f} seconds"
    client_socket.sendall(reply.encode())
    client_socket.close()
