import socket
import time

SERVER_HOST = "127.0.0.1"
SERVER_PORT = 6214

req = input("Enter task name: ").strip() or "BenchmarkTask"

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.settimeout(10.0)

try:
    t_start = time.perf_counter()
    client_socket.connect((SERVER_HOST, SERVER_PORT))
    client_socket.sendall(req.encode())
    reply = client_socket.recv(2048).decode()
    rtt = time.perf_counter() - t_start

    print("Server Response:", reply)
    print(f"Client Measured RTT: {rtt:.4f} seconds")
except Exception as e:
    print("Error:", e)
finally:
    client_socket.close()
