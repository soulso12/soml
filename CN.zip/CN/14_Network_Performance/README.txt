=============================================================================
TOPIC 14: NETWORK PERFORMANCE & QUEUING LATENCY
=============================================================================

WHAT IS THIS TOPIC?
    Network latency is the sum of transmission delay, propagation delay, queuing
    delay, and processing delay. This project measures Round-Trip Time (RTT)
    and simulates M/M/1 queuing behavior.

FILES IN THIS FOLDER:
    1. server.py            - Benchmark Server on port 6214: Simulates processing time.
    2. client.py            - Client: Measures high-resolution Round-Trip Time (RTT).
    3. simpy_simulation.py  - Simulates network queue waiting, service, and turnaround.

HOW TO RUN:
    Method 1: Socket Demo (requires 2 terminals)
        Terminal 1: python server.py
        Terminal 2: python client.py

    Method 2: SimPy Simulation (single terminal)
        Terminal:   python simpy_simulation.py
=============================================================================
