import simpy
import random

random.seed(15)

DEVICES = [
    ("WiFi", 1.0),
    ("Bluetooth", 2.0),
    ("Zigbee", 3.0)
]

def sensor(env, name, interval, stats):
    for seq in range(1, 4):
        yield env.timeout(interval)
        delay = random.uniform(0.1, 0.7)
        yield env.timeout(delay)

        if random.random() < 0.15:
            stats["lost"] += 1
            print(f"[Time {env.now:.2f}s] {name} reading {seq} -> Lost")
        else:
            stats["delivered"] += 1
            stats["delays"].append(delay)
            print(f"[Time {env.now:.2f}s] {name} reading {seq} -> Delivered (Delay: {delay:.2f}s)")

env = simpy.Environment()
stats = {"delivered": 0, "lost": 0, "delays": []}

for name, interval in DEVICES:
    env.process(sensor(env, name, interval, stats))

env.run()

print("Delivered:", stats["delivered"])
print("Lost:", stats["lost"])
