import socket
import datetime

HOST = "127.0.0.1"
PORT = 6213

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_socket.bind((HOST, PORT))
server_socket.listen()
print(f"IoT Gateway running on {HOST}:{PORT}")

while True:
    client_socket, client_address = server_socket.accept()
    raw_payload = client_socket.recv(1024).decode().strip()
    timestamp = datetime.datetime.now().strftime("%H:%M:%S")
    print(f"[{timestamp}] Received from {client_address}: {raw_payload}")

    reply = f"Gateway ACK: Logged '{raw_payload}' at {timestamp}"
    client_socket.sendall(reply.encode())
    client_socket.close()
