import socket

SERVER_HOST = "127.0.0.1"
SERVER_PORT = 6213

device = input("Enter Sensor Name (e.g. TempSensor-01): ").strip() or "TempSensor-01"
reading = input("Enter Reading (e.g. 24.5C): ").strip() or "24.5C"

payload = f"{device}:{reading}"

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.settimeout(5.0)

try:
    client_socket.connect((SERVER_HOST, SERVER_PORT))
    client_socket.sendall(payload.encode())
    reply = client_socket.recv(1024).decode()
    print("Server Response:", reply)
except Exception as e:
    print("Error:", e)
finally:
    client_socket.close()
