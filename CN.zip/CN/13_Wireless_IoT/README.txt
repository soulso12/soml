=============================================================================
TOPIC 13: WIRELESS IOT SENSOR COMMUNICATION
=============================================================================

WHAT IS THIS TOPIC?
    IoT (Internet of Things) devices collect sensor telemetry (temperature, 
    pressure, motion) and transmit it wirelessly to an IoT Gateway using 
    protocols such as WiFi, Bluetooth LE, and Zigbee.

FILES IN THIS FOLDER:
    1. server.py            - IoT Gateway on port 6213: Receives and logs telemetry.
    2. client.py            - IoT Sensor Node: Sends readings (e.g. TempSensor-01:24.5C).
    3. simpy_simulation.py  - Simulates WiFi, BLE, and Zigbee reporting intervals & loss.

HOW TO RUN:
    Method 1: Socket Demo (requires 2 terminals)
        Terminal 1: python server.py
        Terminal 2: python client.py

    Method 2: SimPy Simulation (single terminal)
        Terminal:   python simpy_simulation.py
=============================================================================
